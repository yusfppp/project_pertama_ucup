<?php
$nim = $_POST['nim'];
$nama = $_POST['nama'];
$jurusan = $_POST['jurusan'];
$nilai = $_POST['nilai'];

// menampilkan data
echo "Data dari form POST<br/>";
echo "Nama saya : $nama <br/>";
echo "NIM saya : $nim <br/>";
echo "Jurusan saya : $jurusan <br/>";
echo "Nilai saya : $nilai <br/>";

?>