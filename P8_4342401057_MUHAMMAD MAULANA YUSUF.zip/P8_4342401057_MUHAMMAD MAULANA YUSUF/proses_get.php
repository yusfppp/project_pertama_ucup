<?php
$nim = $_GET['nim'];
$nama = $_GET['nama'];
$jurusan = $_GET['jurusan'];
$nilai = $_GET['nilai'];

// menampilkan data  
echo "Data dari form GET <br/>";
echo "Nama saya : $nama <br/>";
echo "NIM saya : $nim <br/>";
echo "Jurusan saya : $jurusan<br/>";
echo "Nilai saya : $nilai<br/>";
?>