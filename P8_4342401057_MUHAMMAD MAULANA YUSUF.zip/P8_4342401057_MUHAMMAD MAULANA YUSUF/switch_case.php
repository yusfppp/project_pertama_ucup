<?php
$nama = "Muhammad Maulana Yusuf";
$nim = 4342401057;

echo "Nilai Pemrograman Web $nim-$nama <br>";

$nilai = 10;

switch ($nilai) {
    case $nilai >= 90:
        echo "Nilai nya A,pertahankan!";
        break;
    case $nilai >= 85 == 90:
        echo "Nilai nya B, pertahankan!";
        break;
    case $nilai >= 50 == 85:
        echo "Nilai nya C, tingkatkan lagi!";
        break;
    case $nilai > 0 == 50;
        echo "Nilai nya D, tingkatkan lagi";
        break;
    default:
        echo "Nilai nya E, tingkatkan lagi";
}

?>