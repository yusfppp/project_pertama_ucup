<?php
$nama = "Muhammad Maulana Yusuf";
$nim = 4342401057;
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Belajar PHP</title>
</head>

<body>
    <h1> Halo, Selamat datang</h1>
    <h2>NIM anda <?php echo $nim ?></h2>
    <h2>Nama anda <?php echo $nama ?></h2>

</body>

</html>