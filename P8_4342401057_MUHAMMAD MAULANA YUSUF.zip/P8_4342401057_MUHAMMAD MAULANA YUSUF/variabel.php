<?php
// menyimpan data kedalam variabel
$nama = "Muhammad Maulana Yusuf";
$nim = 4342401057;
$jurusan = "Teknik Informatika";
$makanan_favorit = ['nasi goreng', "sate"];
$nilai_matakuliah = ['basis data ' => 90, 'pemerograman web' => 100];

// menampilkan data
echo $nama;
echo $nim;
echo $jurusan;
echo $makanan_favorit;
echo $nilai_matakuliah;

echo "<br> <br>";
echo "var_dump()";
echo "<br>";

// tipe data
var_dump($nama);
var_dump($nim);
var_dump($jurusan);
var_dump($makanan_favorit);
var_dump($nilai_matakuliah);


echo "<br> <br>";
echo "print_r";
echo "<br>";


// tipe data
print_r($nama);
print_r($nim);
print_r($jurusan);
print_r($makanan_favorit);
print_r($nilai_matakuliah);