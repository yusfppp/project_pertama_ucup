<?php
$nama = "Muhammad Maulana Yusuf";
$nim = 4342401057;

echo "Nilai Pemrograman Web $nim-$nama <br>";

$nilai = 90;

if ($nilai > 90) {
    echo "Nilai nya A, pertahankan";
} else if ($nilai <= 90 && $nilai >= 85) {
    echo "Nilai nya B, pertahankan";
} else if ($nilai <= 85 && $nilai >= 50) {
    echo "Nilai nya C, tingkatkan lagi !";
} else if ($nilai <= 50 && $nilai >= 0) {
    echo "Nilai nya D, tingkatkan lagi !";
} else {
    echo "Nilai nya E, tingkatkan lagi !";
}
?>