<?php
$a = 30;
$b = 20;

$jumlah = $a + $b;
$kurang = $a - $b;

$kali = $a * $b;
$bagi = $a / $b;

$sisa_bagi = $a % $b;

echo "Hasil penjumlahan = " . $jumlah . "<br/>";
echo "Hasil Pengurangan = " . $kurang . "<br/>";
echo "Hasil Perkalian = " . $kali . "<br/>";
echo "Hasil pembagian = " . $bagi . "<br/>";
echo "Sisa hasil bagi= " . $sisa_bagi . "<br/>";


?>

