<?php

echo "Hello, World!";
print "Halo dunia!";
print_r("Konnichiwa!");
var_dump("Aloha !");
?>

