<?php
$array = ["nama" => "Yusuf"];
echo "Nama saya adalah {$array['nama']}";

